# SurvivalAnnouncements

A small Paper/Leaf plugin that broadcasts rotating server announcements and a clickable WhatsApp Channel chat message.

## Requirements
- Java 21
- Paper-compatible server (Leaf is Paper-based)
- Minecraft/Paper API dependency configured as `1.21.11-R0.1-SNAPSHOT`

## Build without compiling on your Android phone
1. Create a GitHub repository.
2. Upload the contents of this ZIP to the repository (keep the `.github` folder).
3. Open the repository's **Actions** tab.
4. Select **Build plugin** and tap **Run workflow** (or push to `main`).
5. Open the completed workflow run and download the `SurvivalAnnouncements-1.0.0` artifact.
6. Extract the artifact ZIP. It contains `survival-announcements-1.0.0.jar`.

## Install
1. Stop your server and back up its files.
2. Upload the JAR to the server's `plugins` folder.
3. Start the server once to generate `plugins/SurvivalAnnouncements/config.yml`.
4. Edit `whatsapp.link` in that config and replace the placeholder with your real channel invite URL.
5. Run `/announcement reload` or restart the server.

## Commands
- `/announcement reload` — reload config and restart the announcement timer.
- `/announcement toggle` — enable/disable automatic announcements until restart.

The plugin sends one configured announcement every 30 seconds by default. If WhatsApp is enabled and a real URL is configured, it also broadcasts a clickable chat link.

## Compatibility note
The project targets Paper API `1.21.11-R0.1-SNAPSHOT` and Java 21. Since Leaf is a Paper fork, it should generally support Paper plugins, but test on a backup/staging server first. If the Paper repository does not publish that exact API snapshot, update the `paper-api` version in `pom.xml` to the matching API version available for your exact server build.
