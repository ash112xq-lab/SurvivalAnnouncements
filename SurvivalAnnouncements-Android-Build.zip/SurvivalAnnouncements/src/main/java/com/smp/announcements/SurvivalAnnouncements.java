package com.smp.announcements;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.net.URI;
import java.util.List;

public final class SurvivalAnnouncements extends JavaPlugin {
    private static final LegacyComponentSerializer LEGACY =
            LegacyComponentSerializer.legacyAmpersand();
    private BukkitTask announcementTask;
    private int messageIndex = 0;
    private boolean announcementsEnabled = true;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        startAnnouncements();
        getLogger().info("SurvivalAnnouncements enabled.");
    }

    @Override
    public void onDisable() {
        stopAnnouncements();
    }

    private void startAnnouncements() {
        stopAnnouncements();
        long seconds = Math.max(5L, getConfig().getLong("interval-seconds", 30L));
        long ticks = seconds * 20L;
        announcementTask = Bukkit.getScheduler().runTaskTimer(
                this, this::sendNextAnnouncement, ticks, ticks
        );
    }

    private void stopAnnouncements() {
        if (announcementTask != null) {
            announcementTask.cancel();
            announcementTask = null;
        }
    }

    private void sendNextAnnouncement() {
        if (!announcementsEnabled) return;

        List<String> messages = getConfig().getStringList("announcements");
        if (messages.isEmpty()) return;

        if (messageIndex >= messages.size()) messageIndex = 0;
        Bukkit.broadcast(LEGACY.deserialize(messages.get(messageIndex)));
        messageIndex++;

        if (getConfig().getBoolean("whatsapp.enabled", true)) {
            String link = getConfig().getString("whatsapp.link", "");
            if (isValidHttpUrl(link) && !link.contains("REPLACE_WITH_YOUR_CHANNEL")) {
                String message = getConfig().getString(
                        "whatsapp-message", "&a[WHATSAPP] &fClick here to join our channel!"
                );
                Component clickable = LEGACY.deserialize(message)
                        .clickEvent(ClickEvent.openUrl(link));
                Bukkit.broadcast(clickable);
            }
        }
    }

    private boolean isValidHttpUrl(String value) {
        try {
            URI uri = URI.create(value);
            return ("https".equalsIgnoreCase(uri.getScheme())
                    || "http".equalsIgnoreCase(uri.getScheme()))
                    && uri.getHost() != null;
        } catch (Exception ignored) {
            return false;
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command,
                             String label, String[] args) {
        if (!command.getName().equalsIgnoreCase("announcement")) return false;
        if (!sender.hasPermission("survivalannouncements.admin")) {
            sender.sendMessage(LEGACY.deserialize("&cYou don't have permission."));
            return true;
        }

        if (args.length == 0) {
            sender.sendMessage(LEGACY.deserialize(
                    "&eUsage: /announcement <reload|toggle>"
            ));
            return true;
        }

        if (args[0].equalsIgnoreCase("reload")) {
            reloadConfig();
            messageIndex = 0;
            startAnnouncements();
            sender.sendMessage(LEGACY.deserialize("&aAnnouncements config reloaded."));
            return true;
        }

        if (args[0].equalsIgnoreCase("toggle")) {
            announcementsEnabled = !announcementsEnabled;
            sender.sendMessage(LEGACY.deserialize(
                    announcementsEnabled
                            ? "&aAutomatic announcements enabled."
                            : "&cAutomatic announcements disabled."
            ));
            return true;
        }

        sender.sendMessage(LEGACY.deserialize(
                "&eUsage: /announcement <reload|toggle>"
        ));
        return true;
    }
}
